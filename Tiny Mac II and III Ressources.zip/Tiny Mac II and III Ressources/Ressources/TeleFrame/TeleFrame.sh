cd TeleFrame
DISPLAY=:0 npm start